/**
 * Stuff
 * <ul>
 * <li>Configured H2 Database</li>
 * <li>Lombok Usage in Vehicle</li>
 * <li>Spring Data JPA Usage in VehicleRepository</li>
 * <li>Collection usage in VehicleRepository>
 * </ul>
 * 
 * @Author Jacob Wursteisen
 */
package Group3.demo.vehicles;
