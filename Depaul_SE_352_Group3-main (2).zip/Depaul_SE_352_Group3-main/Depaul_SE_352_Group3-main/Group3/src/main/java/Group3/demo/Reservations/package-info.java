package Group3.demo.Reservations;
/**
 * Stuff
 * <ul>
 * <li>Wrote Api for registration of new users.</li>
 * <li>Debugged JDBC connection issues and was sucessfult in saving the registered users.</li>
 * <li>Wrote Config classes using PasswordEncoder to save encrypted passwords in database.</li>
 * <li>Created LoginForm Model calss for registration purposes.</li>
 * </ul>
 * 
 * @Author Sandeep Turpatti
 */