package Group3.demo.User;
/**
 * Stuff
 * <ul>
 * <li>Wrote User info</li>
 * <li>Debugged JDBC connection issues</li>
 * </ul>
 * 
 * @Author Jacob Wursteisen
 */