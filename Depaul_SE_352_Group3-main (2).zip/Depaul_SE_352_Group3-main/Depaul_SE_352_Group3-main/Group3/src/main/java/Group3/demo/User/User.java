
package Group3.demo.User;

public class User {
    
}
