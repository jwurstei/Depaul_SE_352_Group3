insert into Vehicles (veh_make, veh_model, veh_year) values ('Honda', 'Civic', 2015);
insert into Vehicles (veh_make, veh_model, veh_year) values ('Ford', 'Explorer', 2023);