# Depaul_SE_352_Group3

Andrew Yum - Major: CS Year: Senior<br />
Jake Wursteisen - Major: CS <br />
Sandeep Turpatti - Major: CS